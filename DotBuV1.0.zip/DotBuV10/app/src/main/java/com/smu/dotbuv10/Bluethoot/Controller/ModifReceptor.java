package com.smu.dotbuv10.Bluethoot.Controller;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.smu.dotbuv10.R;

public class ModifReceptor extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modif_receptor);
    }
}
package com.smu.dotbuv10.servicioPaciente.Controler;

public class helperCode {
    int id;
    String code;

    public helperCode(int id, String code) {
        this.id = id;
        this.code = code;
    }
}
